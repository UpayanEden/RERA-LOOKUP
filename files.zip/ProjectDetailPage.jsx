import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { getProject } from "../api";
import { ArrowLeft, ExternalLink } from "lucide-react";
import StatusBadge from "../components/StatusBadge";
import toast from "react-hot-toast";

function Section({ title, children }) {
  return (
    <div className="card p-6">
      <h2 className="text-sm font-semibold text-gray-500 uppercase tracking-wider mb-4">{title}</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">{children}</div>
    </div>
  );
}

function Field({ label, value, mono }) {
  if (value == null || value === "") return null;
  return (
    <div>
      <p className="text-xs text-gray-400 mb-0.5">{label}</p>
      <p className={`text-sm font-medium text-gray-900 ${mono ? "font-mono" : ""}`}>{String(value)}</p>
    </div>
  );
}

function Stat({ label, value, color }) {
  return (
    <div className="card p-4 text-center">
      <p className={`text-2xl font-bold ${color || "text-gray-900"}`}>{value ?? "—"}</p>
      <p className="text-xs text-gray-500 mt-1">{label}</p>
    </div>
  );
}

export default function ProjectDetailPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [project, setProject] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getProject(id)
      .then(({ data }) => setProject(data))
      .catch(() => toast.error("Project not found"))
      .finally(() => setLoading(false));
  }, [id]);

  if (loading) {
    return (
      <div className="space-y-4">
        {Array.from({ length: 3 }).map((_, i) => (
          <div key={i} className="card p-6 h-40 animate-pulse bg-gray-100" />
        ))}
      </div>
    );
  }

  if (!project) return <div className="text-center py-20 text-gray-400">Project not found.</div>;

  const bookingPct = project.booking_rate_pct;

  return (
    <div className="space-y-4 max-w-6xl">
      {/* Back */}
      <button onClick={() => navigate(-1)} className="btn-ghost text-sm">
        <ArrowLeft size={16} /> Back to projects
      </button>

      {/* Hero */}
      <div className="card p-6">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <h1 className="text-xl font-bold text-gray-900">{project.project_name || "Unnamed Project"}</h1>
            <p className="text-sm text-gray-500 mt-1">{project.developer || "Unknown developer"}</p>
            <p className="text-xs text-gray-400 font-mono mt-1">{project.rera_reg_no || project.project_id}</p>
          </div>
          <div className="flex items-center gap-3">
            <StatusBadge status={project.project_status} />
            {project.details_url && (
              <a href={project.details_url} target="_blank" rel="noreferrer" className="btn-ghost border border-gray-200 text-xs">
                <ExternalLink size={14} /> RERA Site
              </a>
            )}
          </div>
        </div>
      </div>

      {/* Stats row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <Stat label="Total units" value={project.total_apartments} />
        <Stat label="Booked" value={project.apartments_booked} color="text-brand-600" />
        <Stat label="Unsold" value={project.unsold_units} color="text-red-500" />
        <Stat
          label="Booking rate"
          value={bookingPct != null ? `${bookingPct}%` : null}
          color={bookingPct > 75 ? "text-green-600" : bookingPct > 40 ? "text-yellow-600" : "text-red-500"}
        />
      </div>

      {/* Details */}
      <Section title="Project details">
        <Field label="Project type"     value={project.project_type} />
        <Field label="Completion date"  value={project.completion_date} />
        <Field label="Extension date"   value={project.extension_completion_date} />
        <Field label="Quarter ending"   value={project.quarter_ending} />
        <Field label="Last updated"     value={project.update_date} />
        <Field label="Flat sizes"       value={project.flat_size_details} />
      </Section>

      <Section title="Location">
        <Field label="Address"        value={project.address} />
        <Field label="Pincode"        value={project.pincode} mono />
        <Field label="District"       value={project.district} />
        <Field label="Police station" value={project.police_station} />
      </Section>

      <Section title="Area & parking">
        <Field label="Land area (sqm)"      value={project.land_area_sqm} />
        <Field label="Built-up area (sqm)"  value={project.builtup_area_sqm} />
        <Field label="Carpet area (sqm)"    value={project.carpet_area_sqm} />
        <Field label="Avg carpet / apt"     value={project.avg_carpet_area_per_apt_sqm} />
        <Field label="Covered parking"      value={project.covered_parking} />
        <Field label="Basement parking"     value={project.basement_parking} />
        <Field label="Mechanical parking"   value={project.mechanical_parking} />
        <Field label="Parking ratio"        value={project.parking_ratio} />
        <Field label="FSI ratio"            value={project.fsi_builtup_land_ratio} />
      </Section>

      <Section title="Booking & status">
        <Field label="Commercial units"         value={project.commercial_units} />
        <Field label="Commercial booked"        value={project.commercial_units_booked} />
        <Field label="Covered parking booked"   value={project.covered_parking_booked} />
        <Field label="Basement parking booked"  value={project.basement_parking_booked} />
        <Field label="Mechanical parking booked" value={project.mechanical_parking_booked} />
      </Section>

      {project.construction_status_summary && (
        <div className="card p-6">
          <h2 className="text-sm font-semibold text-gray-500 uppercase tracking-wider mb-2">Construction status</h2>
          <p className="text-sm text-gray-700">{project.construction_status_summary}</p>
          {project.construction_details && (
            <p className="text-xs text-gray-400 mt-1">{project.construction_details}</p>
          )}
        </div>
      )}

      {project.common_area_status && (
        <div className="card p-6">
          <h2 className="text-sm font-semibold text-gray-500 uppercase tracking-wider mb-2">Common area status</h2>
          <p className="text-sm text-gray-700 whitespace-pre-wrap">{project.common_area_status.replaceAll(" | ", "\n")}</p>
        </div>
      )}
    </div>
  );
}
