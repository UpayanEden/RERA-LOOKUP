import { useEffect, useState, useCallback } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { getProjects, getFilters, addFavourite, removeFavourite, getFavourites } from "../api";
import { Search, ChevronUp, ChevronDown, Star, ChevronLeft, ChevronRight, SlidersHorizontal, X } from "lucide-react";
import toast from "react-hot-toast";
import StatusBadge from "../components/StatusBadge";

const LIMIT = 20;

const COLUMNS = [
  { key: "project_name",    label: "Project Name",  sortable: true },
  { key: "developer",       label: "Developer",     sortable: true },
  { key: "pincode",         label: "Pincode",       sortable: true },
  { key: "district",        label: "District",      sortable: true },
  { key: "project_type",    label: "Type",          sortable: false },
  { key: "project_status",  label: "Status",        sortable: true },
  { key: "total_apartments",label: "Units",         sortable: true },
  { key: "apartments_booked",label: "Booked",       sortable: true },
  { key: "booking_rate_pct",label: "Booking %",     sortable: true },
];

export default function ProjectsPage() {
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();

  const [data, setData]         = useState({ results: [], total: 0, pages: 1 });
  const [loading, setLoading]   = useState(true);
  const [filters, setFilters]   = useState({ pincodes: [], districts: [], statuses: [] });
  const [favPins, setFavPins]   = useState(new Set());
  const [showFilters, setShowFilters] = useState(false);

  // Controlled filter state from URL params
  const page     = parseInt(searchParams.get("page") || "1");
  const search   = searchParams.get("search") || "";
  const pincode  = searchParams.get("pincode") || "";
  const district = searchParams.get("district") || "";
  const status   = searchParams.get("status") || "";
  const sortKey  = searchParams.get("sort") || "";
  const sortDir  = searchParams.get("dir") || "asc";

  const setParam = (key, value) => {
    const p = new URLSearchParams(searchParams);
    if (value) p.set(key, value); else p.delete(key);
    p.set("page", "1");
    setSearchParams(p);
  };

  const setPage = (n) => {
    const p = new URLSearchParams(searchParams);
    p.set("page", String(n));
    setSearchParams(p);
  };

  const toggleSort = (key) => {
    const p = new URLSearchParams(searchParams);
    if (sortKey === key) {
      p.set("dir", sortDir === "asc" ? "desc" : "asc");
    } else {
      p.set("sort", key);
      p.set("dir", "asc");
    }
    setSearchParams(p);
  };

  // Load filter options once
  useEffect(() => {
    getFilters().then(({ data }) => setFilters(data)).catch(() => {});
    getFavourites().then(({ data }) => {
      setFavPins(new Set(data.favourites.map((f) => f.pincode)));
    }).catch(() => {});
  }, []);

  // Load projects on param change
  const loadProjects = useCallback(async () => {
    setLoading(true);
    try {
      const params = { page, limit: LIMIT };
      if (search)   params.search   = search;
      if (pincode)  params.pincode  = pincode;
      if (district) params.district = district;
      if (status)   params.status   = status;
      const { data: res } = await getProjects(params);

      // Client-side sort (API doesn't sort yet)
      let results = res.results;
      if (sortKey) {
        results = [...results].sort((a, b) => {
          const av = a[sortKey] ?? "";
          const bv = b[sortKey] ?? "";
          if (typeof av === "number" && typeof bv === "number") {
            return sortDir === "asc" ? av - bv : bv - av;
          }
          return sortDir === "asc"
            ? String(av).localeCompare(String(bv))
            : String(bv).localeCompare(String(av));
        });
      }
      setData({ ...res, results });
    } catch {
      toast.error("Failed to load projects");
    } finally {
      setLoading(false);
    }
  }, [page, search, pincode, district, status, sortKey, sortDir]);

  useEffect(() => { loadProjects(); }, [loadProjects]);

  const toggleFav = async (pin, e) => {
    e.stopPropagation();
    try {
      if (favPins.has(pin)) {
        await removeFavourite(pin);
        setFavPins((s) => { const n = new Set(s); n.delete(pin); return n; });
        toast.success(`Removed ${pin} from favourites`);
      } else {
        await addFavourite(pin);
        setFavPins((s) => new Set(s).add(pin));
        toast.success(`Added ${pin} to favourites`);
      }
    } catch (err) {
      toast.error(err.response?.data?.detail || "Failed");
    }
  };

  const activeFilters = [pincode, district, status, search].filter(Boolean).length;

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-gray-900">Projects</h1>
          <p className="text-sm text-gray-500">{data.total.toLocaleString()} projects found</p>
        </div>
        <button
          onClick={() => setShowFilters(!showFilters)}
          className={`btn ${showFilters || activeFilters > 0 ? "btn-primary" : "btn-ghost border border-gray-200"}`}
        >
          <SlidersHorizontal size={16} />
          Filters
          {activeFilters > 0 && (
            <span className="bg-white text-brand-600 rounded-full w-5 h-5 flex items-center justify-center text-xs font-bold">
              {activeFilters}
            </span>
          )}
        </button>
      </div>

      {/* Search */}
      <div className="relative">
        <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
        <input
          type="text"
          className="input pl-9"
          placeholder="Search by project name or developer..."
          value={search}
          onChange={(e) => setParam("search", e.target.value)}
        />
      </div>

      {/* Filter panel */}
      {showFilters && (
        <div className="card p-4 grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div>
            <label className="block text-xs font-medium text-gray-500 mb-1">Pincode</label>
            <select className="input" value={pincode} onChange={(e) => setParam("pincode", e.target.value)}>
              <option value="">All pincodes</option>
              {filters.pincodes.map((p) => <option key={p} value={p}>{p}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-xs font-medium text-gray-500 mb-1">District</label>
            <select className="input" value={district} onChange={(e) => setParam("district", e.target.value)}>
              <option value="">All districts</option>
              {filters.districts.map((d) => <option key={d} value={d}>{d}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-xs font-medium text-gray-500 mb-1">Status</label>
            <select className="input" value={status} onChange={(e) => setParam("status", e.target.value)}>
              <option value="">All statuses</option>
              {filters.statuses.map((s) => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>
          {activeFilters > 0 && (
            <div className="sm:col-span-3">
              <button
                className="btn-ghost text-red-500 hover:bg-red-50 text-sm"
                onClick={() => setSearchParams(new URLSearchParams())}
              >
                <X size={14} /> Clear all filters
              </button>
            </div>
          )}
        </div>
      )}

      {/* Table */}
      <div className="card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-gray-50 border-b border-gray-200">
                <th className="w-10 px-3 py-3"></th>
                {COLUMNS.map((col) => (
                  <th
                    key={col.key}
                    className={`px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider whitespace-nowrap ${col.sortable ? "cursor-pointer hover:text-gray-900 select-none" : ""}`}
                    onClick={() => col.sortable && toggleSort(col.key)}
                  >
                    <span className="flex items-center gap-1">
                      {col.label}
                      {col.sortable && sortKey === col.key && (
                        sortDir === "asc" ? <ChevronUp size={14} /> : <ChevronDown size={14} />
                      )}
                    </span>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {loading ? (
                Array.from({ length: 8 }).map((_, i) => (
                  <tr key={i}>
                    <td colSpan={COLUMNS.length + 1} className="px-4 py-3">
                      <div className="h-4 bg-gray-100 rounded animate-pulse w-full" />
                    </td>
                  </tr>
                ))
              ) : data.results.length === 0 ? (
                <tr>
                  <td colSpan={COLUMNS.length + 1} className="px-4 py-12 text-center text-gray-400">
                    No projects found
                  </td>
                </tr>
              ) : (
                data.results.map((project) => (
                  <tr
                    key={project.project_id}
                    className="hover:bg-gray-50 cursor-pointer transition-colors"
                    onClick={() => navigate(`/projects/${project.project_id}`)}
                  >
                    {/* Favourite star */}
                    <td className="px-3 py-3" onClick={(e) => e.stopPropagation()}>
                      <button
                        onClick={(e) => toggleFav(project.pincode, e)}
                        className={`transition-colors ${favPins.has(project.pincode) ? "text-yellow-400" : "text-gray-200 hover:text-yellow-300"}`}
                        title={favPins.has(project.pincode) ? "Remove pincode from favourites" : "Add pincode to favourites"}
                      >
                        <Star size={16} fill={favPins.has(project.pincode) ? "currentColor" : "none"} />
                      </button>
                    </td>
                    <td className="px-4 py-3 font-medium text-gray-900 max-w-xs">
                      <p className="truncate">{project.project_name || "—"}</p>
                      <p className="text-xs text-gray-400 truncate">{project.rera_reg_no || project.project_id}</p>
                    </td>
                    <td className="px-4 py-3 text-gray-600 max-w-xs truncate">{project.developer || "—"}</td>
                    <td className="px-4 py-3 text-gray-600 font-mono">{project.pincode || "—"}</td>
                    <td className="px-4 py-3 text-gray-600">{project.district || "—"}</td>
                    <td className="px-4 py-3 text-gray-600">{project.project_type || "—"}</td>
                    <td className="px-4 py-3"><StatusBadge status={project.project_status} /></td>
                    <td className="px-4 py-3 text-gray-600 text-right">{project.total_apartments ?? "—"}</td>
                    <td className="px-4 py-3 text-gray-600 text-right">{project.apartments_booked ?? "—"}</td>
                    <td className="px-4 py-3 text-right">
                      {project.booking_rate_pct != null ? (
                        <span className={`font-medium ${project.booking_rate_pct > 75 ? "text-green-600" : project.booking_rate_pct > 40 ? "text-yellow-600" : "text-gray-600"}`}>
                          {project.booking_rate_pct}%
                        </span>
                      ) : "—"}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {data.pages > 1 && (
          <div className="flex items-center justify-between px-4 py-3 border-t border-gray-100">
            <p className="text-sm text-gray-500">
              Page {page} of {data.pages} ({data.total.toLocaleString()} results)
            </p>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setPage(page - 1)}
                disabled={page <= 1}
                className="btn-ghost border border-gray-200 px-2 py-1.5 disabled:opacity-40"
              >
                <ChevronLeft size={16} />
              </button>
              <button
                onClick={() => setPage(page + 1)}
                disabled={page >= data.pages}
                className="btn-ghost border border-gray-200 px-2 py-1.5 disabled:opacity-40"
              >
                <ChevronRight size={16} />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
