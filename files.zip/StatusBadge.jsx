export default function StatusBadge({ status }) {
  if (!status) return <span className="text-gray-400 text-sm">—</span>;

  const s = status.toLowerCase();
  let cls = "badge ";

  if (s.includes("complet")) cls += "bg-green-100 text-green-800";
  else if (s.includes("ongoing") || s.includes("progress")) cls += "bg-blue-100 text-blue-800";
  else if (s.includes("lapse") || s.includes("expire")) cls += "bg-red-100 text-red-800";
  else if (s.includes("extend")) cls += "bg-yellow-100 text-yellow-800";
  else cls += "bg-gray-100 text-gray-700";

  return <span className={cls}>{status}</span>;
}
