import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { getChanges, getChangesSummary } from "../api";
import { Activity, ChevronLeft, ChevronRight, TrendingUp } from "lucide-react";
import toast from "react-hot-toast";

function FieldPill({ field }) {
  const colors = {
    apartments_booked:  "bg-blue-50 text-blue-700",
    project_status:     "bg-purple-50 text-purple-700",
    booking_rate_pct:   "bg-green-50 text-green-700",
    unsold_units:       "bg-red-50 text-red-700",
  };
  return (
    <span className={`badge ${colors[field] || "bg-gray-100 text-gray-600"}`}>
      {field.replaceAll("_", " ")}
    </span>
  );
}

function ValueChange({ oldVal, newVal }) {
  const fmt = (v) => (v == null ? "—" : String(v));
  return (
    <span className="text-sm">
      <span className="text-red-500 line-through">{fmt(oldVal)}</span>
      <span className="mx-2 text-gray-300">→</span>
      <span className="text-green-600 font-medium">{fmt(newVal)}</span>
    </span>
  );
}

export default function ChangesPage() {
  const navigate = useNavigate();
  const [changes, setChanges]   = useState({ results: [], total: 0, pages: 1 });
  const [summary, setSummary]   = useState(null);
  const [page, setPage]         = useState(1);
  const [pincode, setPincode]   = useState("");
  const [loading, setLoading]   = useState(true);

  useEffect(() => {
    getChangesSummary()
      .then(({ data }) => setSummary(data))
      .catch(() => {});
  }, []);

  useEffect(() => {
    setLoading(true);
    const params = { page, limit: 50 };
    if (pincode) params.pincode = pincode;
    getChanges(params)
      .then(({ data }) => setChanges(data))
      .catch(() => toast.error("Failed to load changes"))
      .finally(() => setLoading(false));
  }, [page, pincode]);

  return (
    <div className="space-y-4 max-w-5xl">
      <div>
        <h1 className="text-xl font-bold text-gray-900">Changes Feed</h1>
        <p className="text-sm text-gray-500">Field-level diff log from every scrape run</p>
      </div>

      {/* 7-day summary */}
      {summary && (
        <div className="card p-5">
          <div className="flex items-center gap-2 mb-4">
            <TrendingUp size={16} className="text-brand-600" />
            <h2 className="font-semibold text-sm text-gray-700">Last 7 days</h2>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 mb-4">
            <div className="text-center">
              <p className="text-2xl font-bold text-gray-900">{summary.total_changes.toLocaleString()}</p>
              <p className="text-xs text-gray-400">Total changes</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-brand-600">{summary.total_projects_affected}</p>
              <p className="text-xs text-gray-400">Projects affected</p>
            </div>
            <div className="text-center col-span-2 sm:col-span-1">
              <p className="text-2xl font-bold text-green-600">{summary.by_field?.length ?? 0}</p>
              <p className="text-xs text-gray-400">Unique fields changed</p>
            </div>
          </div>
          {summary.by_field?.length > 0 && (
            <div className="flex flex-wrap gap-2">
              {summary.by_field.slice(0, 8).map((f) => (
                <div key={f.field} className="flex items-center gap-1.5">
                  <FieldPill field={f.field} />
                  <span className="text-xs text-gray-400">×{f.change_count}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Filter */}
      <div className="flex items-center gap-3">
        <input
          type="text"
          className="input max-w-xs font-mono"
          placeholder="Filter by pincode..."
          maxLength={6}
          value={pincode}
          onChange={(e) => { setPincode(e.target.value.replace(/\D/, "")); setPage(1); }}
        />
        {pincode && (
          <button onClick={() => { setPincode(""); setPage(1); }} className="btn-ghost text-sm">
            Clear
          </button>
        )}
        <p className="text-sm text-gray-400 ml-auto">{changes.total.toLocaleString()} changes</p>
      </div>

      {/* Changes list */}
      <div className="card divide-y divide-gray-100">
        {loading ? (
          Array.from({ length: 8 }).map((_, i) => (
            <div key={i} className="px-5 py-4 flex gap-3 animate-pulse">
              <div className="h-4 bg-gray-100 rounded flex-1" />
            </div>
          ))
        ) : changes.results.length === 0 ? (
          <div className="py-16 text-center">
            <Activity size={32} className="mx-auto text-gray-200 mb-3" />
            <p className="text-gray-400">No changes recorded yet</p>
            <p className="text-sm text-gray-300 mt-1">Changes appear after the first scrape completes</p>
          </div>
        ) : (
          changes.results.map((c) => (
            <div
              key={c._id}
              className="px-5 py-3.5 flex flex-wrap items-start gap-x-4 gap-y-1.5 hover:bg-gray-50 cursor-pointer"
              onClick={() => navigate(`/projects/${c.project_id}`)}
            >
              <div className="min-w-0 flex-1">
                <p className="text-sm font-medium text-gray-900 truncate">
                  {c.project_name || c.project_id}
                </p>
                <div className="flex flex-wrap items-center gap-2 mt-1">
                  {c.pincode && (
                    <span className="text-xs text-gray-400 font-mono">{c.pincode}</span>
                  )}
                  <FieldPill field={c.field} />
                  <ValueChange oldVal={c.old_value} newVal={c.new_value} />
                </div>
              </div>
              <p className="text-xs text-gray-400 shrink-0 mt-0.5">
                {new Date(c.changed_at).toLocaleString("en-IN", {
                  day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit"
                })}
              </p>
            </div>
          ))
        )}
      </div>

      {/* Pagination */}
      {changes.pages > 1 && (
        <div className="flex items-center justify-between">
          <p className="text-sm text-gray-500">Page {page} of {changes.pages}</p>
          <div className="flex gap-2">
            <button onClick={() => setPage(page - 1)} disabled={page <= 1} className="btn-ghost border border-gray-200 px-2 py-1.5 disabled:opacity-40">
              <ChevronLeft size={16} />
            </button>
            <button onClick={() => setPage(page + 1)} disabled={page >= changes.pages} className="btn-ghost border border-gray-200 px-2 py-1.5 disabled:opacity-40">
              <ChevronRight size={16} />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
