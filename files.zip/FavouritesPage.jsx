import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { getFavourites, removeFavourite, addFavourite, getProjects } from "../api";
import { Star, Trash2, Plus, Building2, ChevronRight } from "lucide-react";
import toast from "react-hot-toast";
import StatusBadge from "../components/StatusBadge";

export default function FavouritesPage() {
  const navigate = useNavigate();
  const [favourites, setFavourites] = useState([]);
  const [loading, setLoading]       = useState(true);
  const [addInput, setAddInput]     = useState("");
  const [adding, setAdding]         = useState(false);
  const [expanded, setExpanded]     = useState(null);
  const [pinProjects, setPinProjects] = useState({});

  const loadFavourites = async () => {
    try {
      const { data } = await getFavourites();
      setFavourites(data.favourites);
    } catch {
      toast.error("Failed to load favourites");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { loadFavourites(); }, []);

  const handleAdd = async () => {
    const pin = addInput.trim();
    if (!/^\d{6}$/.test(pin)) { toast.error("Enter a valid 6-digit pincode"); return; }
    setAdding(true);
    try {
      await addFavourite(pin);
      toast.success(`Added ${pin}`);
      setAddInput("");
      loadFavourites();
    } catch (err) {
      toast.error(err.response?.data?.detail || "Failed to add");
    } finally {
      setAdding(false);
    }
  };

  const handleRemove = async (pin) => {
    try {
      await removeFavourite(pin);
      setFavourites((f) => f.filter((x) => x.pincode !== pin));
      toast.success(`Removed ${pin}`);
    } catch {
      toast.error("Failed to remove");
    }
  };

  const toggleExpand = async (pin) => {
    if (expanded === pin) { setExpanded(null); return; }
    setExpanded(pin);
    if (!pinProjects[pin]) {
      try {
        const { data } = await getProjects({ pincode: pin, limit: 50 });
        setPinProjects((p) => ({ ...p, [pin]: data.results }));
      } catch {
        toast.error("Failed to load projects");
      }
    }
  };

  return (
    <div className="space-y-4 max-w-3xl">
      <div>
        <h1 className="text-xl font-bold text-gray-900">Favourite Pincodes</h1>
        <p className="text-sm text-gray-500">Track RERA projects by pincode</p>
      </div>

      {/* Add pincode */}
      <div className="card p-4 flex items-center gap-3">
        <input
          type="text"
          className="input flex-1"
          placeholder="Enter a 6-digit pincode..."
          value={addInput}
          maxLength={6}
          onChange={(e) => setAddInput(e.target.value.replace(/\D/, ""))}
          onKeyDown={(e) => e.key === "Enter" && handleAdd()}
        />
        <button onClick={handleAdd} disabled={adding} className="btn-primary shrink-0">
          <Plus size={16} /> Add
        </button>
      </div>

      {/* List */}
      {loading ? (
        <div className="space-y-2">
          {Array.from({ length: 3 }).map((_, i) => (
            <div key={i} className="card p-5 h-20 animate-pulse bg-gray-100" />
          ))}
        </div>
      ) : favourites.length === 0 ? (
        <div className="card p-12 text-center">
          <Star size={32} className="mx-auto text-gray-200 mb-3" />
          <p className="text-gray-500 font-medium">No favourite pincodes yet</p>
          <p className="text-sm text-gray-400 mt-1">Add a pincode above to start tracking projects</p>
        </div>
      ) : (
        <div className="space-y-2">
          {favourites.map((fav) => (
            <div key={fav.pincode} className="card overflow-hidden">
              {/* Summary row */}
              <div className="flex items-center gap-4 p-4">
                <div className="w-10 h-10 rounded-lg bg-brand-50 flex items-center justify-center shrink-0">
                  <Star size={18} className="text-brand-600" fill="currentColor" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <p className="font-semibold text-gray-900 font-mono">{fav.pincode}</p>
                    <span className="badge bg-brand-50 text-brand-700">{fav.total_projects} projects</span>
                  </div>
                  <div className="flex flex-wrap gap-1.5 mt-1.5">
                    {fav.statuses?.slice(0, 4).map((s) => <StatusBadge key={s} status={s} />)}
                    {fav.statuses?.length > 4 && (
                      <span className="badge bg-gray-100 text-gray-500">+{fav.statuses.length - 4} more</span>
                    )}
                  </div>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <button
                    onClick={() => toggleExpand(fav.pincode)}
                    className="btn-ghost border border-gray-200 text-xs"
                  >
                    <Building2 size={14} />
                    {expanded === fav.pincode ? "Hide" : "View projects"}
                  </button>
                  <button
                    onClick={() => navigate(`/projects?pincode=${fav.pincode}`)}
                    className="btn-ghost border border-gray-200 text-xs"
                  >
                    <ChevronRight size={14} />
                  </button>
                  <button onClick={() => handleRemove(fav.pincode)} className="btn-danger text-xs">
                    <Trash2 size={14} />
                  </button>
                </div>
              </div>

              {/* Expanded project list */}
              {expanded === fav.pincode && (
                <div className="border-t border-gray-100 divide-y divide-gray-50">
                  {!pinProjects[fav.pincode] ? (
                    <div className="p-4 text-sm text-gray-400 animate-pulse">Loading projects...</div>
                  ) : pinProjects[fav.pincode].length === 0 ? (
                    <div className="p-4 text-sm text-gray-400">No projects found</div>
                  ) : (
                    pinProjects[fav.pincode].map((p) => (
                      <div
                        key={p.project_id}
                        className="flex items-center justify-between px-4 py-3 hover:bg-gray-50 cursor-pointer"
                        onClick={() => navigate(`/projects/${p.project_id}`)}
                      >
                        <div className="min-w-0">
                          <p className="text-sm font-medium text-gray-900 truncate">{p.project_name || "—"}</p>
                          <p className="text-xs text-gray-400 truncate">{p.developer || "—"}</p>
                        </div>
                        <div className="flex items-center gap-3 shrink-0 ml-4">
                          <StatusBadge status={p.project_status} />
                          {p.booking_rate_pct != null && (
                            <span className="text-xs text-gray-500">{p.booking_rate_pct}% booked</span>
                          )}
                          <ChevronRight size={14} className="text-gray-300" />
                        </div>
                      </div>
                    ))
                  )}
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
